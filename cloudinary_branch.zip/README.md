# pawsome
It's an Ecommerce website desined in express using ejs


ngrok http 3000

https://github.com/najiyasheri/pawsome/pull/12