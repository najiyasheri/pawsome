const Cart = require("../models/Cart");
const Product = require("../models/Product");
const Variant = require('../models/ProductVariant')

const loadCart = async (req, res) => {
  try {
    if (!req.session.user) {
      return res.status(401).send("You must be logged in to view the cart");
    }

    const userId = req.session.user._id;

     const message = req.query.msg ? decodeURIComponent(req.query.msg) : null;


    const cart = await Cart.findOne({ userId })
      .populate({
        path: "items.productId",
        populate: { path: "categoryId" },
      })
      .populate("items.variantId");

    let stockMessage = ""; // 👈 new variable
    let stockAdjusted = false; // track if any changes happened

    if (cart && cart.items.length > 0) {
      for (let item of cart.items) {
        const variant = item.variantId;

        if (!variant) continue;

        if (variant.stock <= 0) {
          item.quantity = 0;
          stockAdjusted = true;
          continue;
        }

        if (item.quantity > variant.stock) {
          item.quantity = variant.stock;
          stockAdjusted = true;

          await Cart.updateOne(
            {
              userId,
              "items.productId": item.productId,
              "items.variantId": item.variantId,
            },
            { $set: { "items.$.quantity": variant.stock } }
          );
        }
      }
    }

    if (stockAdjusted) {
      stockMessage =
        "Some items in your cart were updated due to limited stock availability.";
    }

    if (!cart || cart.items.length === 0) {
      return res.render("user/cart", {
        title: "Cart",
        layout: "layouts/userLayout",
        user: req.session.user,
        cart: null,
        summary: {
          totalItems: 0,
          totalQuantity: 0,
          deliveryCharge: 0,
          totalPrice: 0,
        },
      });
    }

    const enrichedItems = cart.items
      .map((item) => {
        const product = item.productId;
        const variant = item.variantId;
        const category = product?.categoryId;

        if (!product || !variant) return null;

        const basePrice = parseFloat(product.basePrice || 0);
        const productOffer = parseFloat(product.discountPercentage || 0);
        const categoryOffer = parseFloat(category?.offerPercentage || 0);
        const discountPercentage =
          productOffer > categoryOffer ? productOffer : categoryOffer;
        const oldPrice = basePrice + variant.additionalPrice;
        const finalPrice = Math.round(
          oldPrice * (1 - discountPercentage / 100)
        );

        return {
          productId: product._id,
          variantId: variant._id,
          name: product.name,
          image: product.images?.[0],
          size: variant.size,
          stock: variant.stock,
          price: finalPrice,
          quantity: item.quantity,
          subtotal: finalPrice * item.quantity,
          discount: discountPercentage,
        };
      })
      .filter(Boolean);

    const summary = {
      totalItems: enrichedItems.length,
      totalQuantity: enrichedItems.reduce(
        (sum, item) => sum + item.quantity,
        0
      ),
      deliveryCharge: 50,
      totalPrice: enrichedItems.reduce((sum, item) => sum + item.subtotal, 0),
    };

    let hasOutOfStock = enrichedItems.some((item) => item.stock === 0);

    res.render("user/cart", {
      title: "Cart",
      layout: "layouts/userLayout",
      user: req.session.user,
      cart: {
        items: enrichedItems,
        total: summary.totalPrice + summary.deliveryCharge,
      },
      summary,
      hasOutOfStock,
      stockMessage, 
      message,
    });
  } catch (err) {
    console.error("Error loading cart:", err);
    res.status(500).send("Server error");
  }
};



const addToCart = async (req, res) => {
  try {
    if (!req.session.user) {
      return res.status(401).json({
        success: false,
        message: "You must be logged in to add items to the cart",
      });
    }

    const { productId, variantId } = req.body;
    const userId = req.session.user._id;
    const quantity = 1;

    const product = await Product.findById(productId);
    if (!product || product.isBlocked)
      return res
        .status(404)
        .json({ success: false, message: "Product not found" });

    const variant = await Variant.findOne({
      _id: variantId,
      productId: productId,
      status: true, 
    });

    if (!variant)
      return res
        .status(404)
        .json({ success: false, message: "Variant not found" });

    if (variant.stock < quantity) {
      return res.status(400).json({ success: false, message: "Out of stock" });
    }

    let cart = await Cart.findOne({ userId });
    if (!cart) {
      cart = new Cart({ userId, items: [] });
    }
    
    if (quantity > variant.stock) {
      return res
        .status(400)
        .json({ success: false, message: "Not enough stock available" });
    }

      cart.items.push({
        productId,
        variantId,
        quantity,
      });
    
    await cart.save();

    res.status(200).json({
      success: true,
      message: "Product successfully added to cart",
      stock: variant.stock,
    });
  } catch (err) {
    console.error("Error in addToCart:", err);
    res.status(500).json({ success: false, message: "Server error" });
  }
};


const updateCart = async (req, res) => {
  try {
    const { productId, variantId, action } = req.body;
    const userId = req.session.user._id;
    const cart = await Cart.findOne({ userId })

    if (!cart) {
      return res.status(404).json({ error: "Cart not found" });
    }

    const itemIndex = cart.items.findIndex(
      (item) =>
        item.productId._id.toString() === productId &&
        item.variantId._id.toString() === variantId
    );

    if (itemIndex === -1) {
      return res.status(404).json({ error: "Item not found" });
    }

    const item = cart.items[itemIndex];
    const variant = await Variant.findById(variantId);

    if (!variant) {
      return res.status(404).json({ error: "Variant not found" });
    }

    if (action === "increase") {
      if (item.quantity + 1 > variant.stock) {
        return res
          .status(400)
          .json({ error: "Cannot add more than available stock" });
      }
      item.quantity += 1;
    } else if (action === "decrease") {
      item.quantity -= 1;
      if (item.quantity <= 0) {
        cart.items.splice(itemIndex, 1);
      }
    }

    await cart.save();

 
    const totalQuantity = cart.items.reduce((sum, i) => sum + i.quantity, 0);
    
    const summary = { totalQuantity };

    await cart.save();


    res.json({ cart, summary });
  } catch (err) {
    console.error("Error updating cart:", err);
    res.status(500).json({ error: "Server error while updating cart" });
  }
};


const removeCart = async (req, res) => {
  try {
    if (!req.session.user) {
      return res.redirect("/login");
    }

    const { productId, variantId } = req.body; 
    const userId = req.session.user._id;
    const cart = await Cart.findOne({ userId });

    if (!cart) {
      return res.redirect("/cart?error=Cart not found");
    }

    cart.items = cart.items.filter(
      (item) =>
        item.productId.toString() !== productId ||
        item.variantId.toString() !== variantId
    );

    await cart.save();
    res.redirect("/cart");
  } catch (err) {
    console.error(err);
    res.redirect("/cart?error=Server error");
  }
};

module.exports = {
  loadCart,
  addToCart,
  updateCart,
  removeCart,
};
